1. Operate preprocess.py
2. Operate machineLearning.py