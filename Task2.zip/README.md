# Big-data-course-project
COMP5434 Big-data-course-project

'2.1_Train_Data_Sumed_For_Process.csv' is the original data has been map-reduced

1. Operate preprocess.py
2. Operate machineLearning.py (If you want to see K-Fold process, in def main, there is a evaluation() function has been ###)

results:
in 'Test_Data.csv'